# Input a string "Python‟. Write a program to print all the letters except the letter ‟y‟ using continue keyword.


a=input("Enter a string:")
for i in a:
    if i=="y":
        continue
    print(i)
    
# Author: Ansh Garg
# Date: 17-3-23