# WAP to read an integer ‘n’ from STDIN. For allnon-negative integers i<n, print i**2 on a separate line.


a = int(input("Enter a number: "))
for i in range(a):
    print(i**2)

# Author: Ansh Garg
# Date: 17-3-23